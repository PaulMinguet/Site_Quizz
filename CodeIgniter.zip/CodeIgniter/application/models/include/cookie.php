<?php
setcookie('user', 'Louis', time() + 60*60*24*30);
var_dump($_COOKIE); 