<?php if ($error) : ?>
    <div class="title2 alert">
        <?php $error ?>
    </div>
<?php endif; ?>

<?php if ($success) : ?>
    <div class="title2 success">
        <?php $success ?>
    </div>
<?php endif; ?>
  