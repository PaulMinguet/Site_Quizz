<img src="../../img/cactus2.png" alt="" srcset="" class="cactus" id="cac_left">		<!--Affichage des cactus-->
<img src="../../img/cactus2.png" alt="" srcset="" class="cactus" id="cac_right">
