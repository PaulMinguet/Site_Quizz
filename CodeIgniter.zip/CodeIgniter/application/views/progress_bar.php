<div id="progressbar"></div>
<div id="scrollPos"></div>

<script src="../../js/progress_bar.js"></script>
