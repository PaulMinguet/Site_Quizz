
<h1 class='bienvenue'><?php $_SESSION['username']?></h1>

