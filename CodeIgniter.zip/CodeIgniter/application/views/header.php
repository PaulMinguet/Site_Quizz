<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">										<!--Importation des fichiers dont on a besoin-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type = "text/css" 
	    href = "../../css/style.css">
        <script src="../../js/btnSelect.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@500&family=Jost:ital,wght@1,300;0,500;0,600&family=Metal+Mania&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title>Quizz</title>
</head>

    
<body>
