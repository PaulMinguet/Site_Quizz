<div class="container-time">
    <h1 class="timer" id="timer"></h1>
</div>
<script src="../../js/timer.js"></script>


