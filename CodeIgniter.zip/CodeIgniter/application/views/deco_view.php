<html>
	<body>
		<h1 class="title">Déconnection<br>--<br>Vous avez bien été déconnecté</h1>
	</body>
</html>