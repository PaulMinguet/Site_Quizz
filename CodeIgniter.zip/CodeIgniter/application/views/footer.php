
<footer class="footer"><h1>Designed & Developped by Paul Minguet & Louis Daubié</h1></footer>
