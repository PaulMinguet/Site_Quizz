/* 
function onActif() {
    
    inactif.classList.remove("onSelect");
}

function onInactif() {
    console.log("actif");
    document.getElementById("inactif").classList.add("onSelect");
    actif.classList.remove("onSelect");
} */

/* var actif = document.getElementById("actif")
var inactif = document.getElementById("inactif")
 */


/* 
 actif.onclick = function () {
    actif.classList.add("onSelect");
} 
inactif.onclick = function () {
    console.log("inactif");
    actif.classList.add("onSelect");
    
} */